﻿using System;
using System.Windows.Forms;

namespace Triangulo
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC, valid;

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoA.Text, out ladoA) || !Double.TryParse(txtLadoB.Text, out ladoB) || !Double.TryParse(txtLadoC.Text, out ladoC) || ladoA <= 0 || ladoB <= 0 || ladoC <= 0)
            {
                MessageBox.Show("Números inválidos!");
                txtLadoA.Focus();
            }
            else if ((ladoA < ladoB+ladoC) && (ladoA > Math.Abs(ladoB - ladoC)) && (ladoB < ladoA + ladoC) && (ladoB > Math.Abs(ladoA - ladoC)) && (ladoC < ladoA + ladoB) && (ladoC > Math.Abs(ladoA - ladoB)))
            {
                if ((ladoA == ladoB) && (ladoB == ladoC))
                {
                    txtValid.Text = "Triângulo Equilátero";
                }
                else if (((ladoA == ladoB) && (ladoB != ladoC)) || ((ladoA == ladoC) && (ladoB != ladoC)) || ((ladoB == ladoC) && (ladoA != ladoC)))
                {
                    txtValid.Text = "Triângulo Isósceles";
                }
                else
                {
                    txtValid.Text = "Triângulo Escaleno";
                }
            }
            else
            {
                MessageBox.Show("Deu ruim aí.");
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoA.Text, out ladoA))
            {
                MessageBox.Show("Tamanho inválido!");
            }
            else if (ladoA <= 0)
            {
                MessageBox.Show("O lado deve ser maior que zero!");
            }
        }

        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoB.Text, out ladoB))
            {
                MessageBox.Show("Tamanho inválido!");
            }
            else if (ladoB <= 0)
            {
                MessageBox.Show("O lado deve ser maior que zero!");
            }
        }

        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoC.Text, out ladoC))
            {
                MessageBox.Show("Tamanho inválido!");
            }
            else if (ladoC <= 0)
            {
                MessageBox.Show("O lado deve ser maior que zero!");
            }
        }
    }
}
